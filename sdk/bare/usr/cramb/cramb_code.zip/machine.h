#ifndef MACHINE_H
#define MACHINE_H

#include "../../sys/defines.h"

#define L (0.0075) //Henry
#define R (10.0)     //Ohms

#endif // MACHINE_H
