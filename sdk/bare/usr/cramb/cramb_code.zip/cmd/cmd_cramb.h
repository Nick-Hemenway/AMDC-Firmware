#ifndef CMD_CRAMB_H
#define CMD_CRAMB_H

void cmd_cramb_register(void);

int cmd_cramb(char **argv, int argc);

#endif // CMD_CRAMB_H
