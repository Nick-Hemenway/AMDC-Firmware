#ifndef CMD_CRAMB_AXIAL_H
#define CMD_CRAMB_AXIAL_H

void cmd_cramb_axial_register(void);

int cmd_cramb_axial(char **argv, int argc);

#endif // CMD_CRAMB_H
