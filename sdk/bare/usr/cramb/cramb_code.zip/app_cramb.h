#ifndef APP_CRAMB_H
#define APP_CRAMB_H

void app_cramb_init(void);
void app_cramb_axial_init(void);

#endif // APP_CRAMB_H
